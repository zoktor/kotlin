package js

annotation class native()

public native fun libf(): Int {
  return 3
}